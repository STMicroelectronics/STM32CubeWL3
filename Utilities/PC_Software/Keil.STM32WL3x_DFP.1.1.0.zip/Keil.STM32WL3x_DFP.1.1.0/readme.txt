/ **
  ***********************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WL3x devices support on MDK-ARM.
  ***********************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************/
  
  Package general purpose:
  ======================================================================================================================	
    These packages contains the needed files to be installed in order to support STM32WL3xx devices by MDK-ARM v5.25 and laters.
    We inform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32WL3x_DFP.1.1.0.pack" adds the following:
  ===============================================================================================================================
	1. Part numbers for  :
		- Product lines: STM32WL33xCxx/STM32WL33xBxx/STM32WL33x8xx/STM32WL30xBxx/STM32WL30x8xx/STM32WL31xBxx/STM32WL31x8xx.
  
	2. Automatic STM32WL3x flash algorithm selection 
    
	3. STM32WL33 SVD file v1r0.
	   STM32WL31 & STM32WL30 SVD file v1r0.


  How to use:
  ===============================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
	 
	* Double Clic on  "Keil.STM32WL3x_DFP.1.1.0.pack" in order to install this pack in 
	  the Keil install directory.
	  
    PS: Please make sure that you are using PackUnzip.exe to run this pack.

  SVD files ReleaseNotes:
  ===============================================================================================================================
	=======================================================
	STM32WL3x_v1r1:     Official release
	=======================================================
	V1.0   First release with support for STM32WL33
	V1.1   Adding support for STM32WL30 and STM32WL31







	



